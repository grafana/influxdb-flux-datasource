# Change Log

## [5.3.2] - 2019-07-07

- Fix for range error when expanding suggestion [#39](https://github.com/grafana/influxdb-flux-datasource/pull/39)

## [5.3.0] - 2019-06-11

- Update packages
- Add circleci publishing
- Add support for Influx V2.0 Alpha Server
