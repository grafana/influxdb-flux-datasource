# Change Log

## [5.3.0] - 2019-06-11

- Update packages
- Add circleci publishing
- Add support for Influx V2.0 Alpha Server
